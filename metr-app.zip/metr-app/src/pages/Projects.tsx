import React, { useState } from 'react';
import { Plus, Search, ExternalLink, MoreVertical, SlidersHorizontal, ChevronDown, Edit, Archive, Trash2 } from 'lucide-react';

interface ProjectsProps {
  projects: any[];
  setProjects: (projects: any[]) => void; // pour mettre à jour l’état parent
  onCreateProject: () => void;
  onOpenProject: (id: number) => void;
}

export default function Projects({ projects, setProjects, onCreateProject, onOpenProject }: ProjectsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showArchived, setShowArchived] = useState(false);
  const [sortBy, setSortBy] = useState('date');
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [openMenuId, setOpenMenuId] = useState<number | null>(null);

  const getStatusDisplay = (statut: string) => {
    const statusMap: any = {
      'En_cours': { label: 'En cours', color: 'bg-green-100 text-green-700' },
      'Termine': { label: 'Terminé', color: 'bg-blue-100 text-blue-700' },
      'En_attente': { label: 'Brouillon', color: 'bg-yellow-100 text-yellow-700' },
      'Archive': { label: 'Archivé', color: 'bg-gray-100 text-gray-700' }
    };
    return statusMap[statut] || statusMap['En_attente'];
  };

  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.nom.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.client && p.client.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || p.statut === statusFilter;
    const matchesArchived = showArchived || p.statut !== 'Archive';
    return matchesSearch && matchesStatus && matchesArchived;
  });

  const stats = {
    total: projects.length,
    actifs: projects.filter(p => p.statut !== 'Archive').length,
    archives: projects.filter(p => p.statut === 'Archive').length
  };

  const formatDate = (dateString: string) => dateString ? new Date(dateString).toLocaleDateString('fr-FR') : 'Date inconnue';

  // Changement de statut via backend
  const handleChangeStatus = async (projectId: number, newStatus: string) => {
    try {
      const res = await fetch(`http://localhost:3001/api/projects/${projectId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newStatus })
      });
      if (!res.ok) throw new Error('Erreur serveur');

      // Mise à jour locale
      const updatedProjects = projects.map(p => p.idProjet === projectId ? { ...p, statut: newStatus } : p);
      setProjects(updatedProjects);
      setOpenMenuId(null);
    } catch (err: any) {
      alert('Impossible de changer le statut: ' + err.message);
    }
  };

  const handleArchiveProject = (projectId: number) => handleChangeStatus(projectId, 'Archive');

  const handleDeleteProject = async (projectId: number) => {
    if (!confirm('⚠️ Supprimer ce projet définitivement ?')) return;
    try {
      const res = await fetch(`http://localhost:3001/api/projects/${projectId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Erreur serveur');
      const updatedProjects = projects.filter(p => p.idProjet !== projectId);
      setProjects(updatedProjects);
    } catch (err: any) {
      alert('Impossible de supprimer le projet: ' + err.message);
    }
  };

  const sortOptions = [
    { value: 'date', label: 'Dernière modification' },
    { value: 'name', label: 'Nom (A-Z)' },
    { value: 'client', label: 'Client (A-Z)' },
    { value: 'status', label: 'Statut' }
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-[#1e3a8a]">Mes projets</h2>
        <button onClick={onCreateProject} className="bg-[#f97316] text-white px-6 py-3 rounded-lg hover:bg-[#ea580c] transition-colors font-medium flex items-center gap-2">
          <Plus className="w-5 h-5" /> Créer un projet
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6 flex flex-col md:flex-row md:items-center md:gap-4">
        <div className="flex-1 relative mb-4 md:mb-0">
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            placeholder="Rechercher un projet ou client..." className="w-full pl-10 px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent" />
        </div>

        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1e3a8a] w-48">
          <option value="all">Tous les statuts</option>
          <option value="En_cours">En cours</option>
          <option value="Termine">Terminé</option>
          <option value="En_attente">Brouillon</option>
          <option value="Archive">Archivé</option>
        </select>

        <label className="flex items-center gap-2 mt-2 md:mt-0 cursor-pointer">
          <input type="checkbox" checked={showArchived} onChange={e => setShowArchived(e.target.checked)} className="w-4 h-4 rounded border-gray-300 text-[#1e3a8a] focus:ring-[#1e3a8a]" />
          <span className="text-sm text-gray-700">Afficher archivés</span>
        </label>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredProjects.map(project => {
            const status = getStatusDisplay(project.statut);
            return (
              <div key={project.idProjet} className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-bold text-lg text-gray-900 mb-1 line-clamp-1">{project.nom}</h3>
                    <p className="text-sm text-gray-500 line-clamp-1">{project.client || 'Sans client'}</p>
                  </div>

                  {/* Menu 3 points */}
                  <div className="relative">
                    <button onClick={() => setOpenMenuId(openMenuId === project.idProjet ? null : project.idProjet)} className="p-1 hover:bg-gray-100 rounded transition-colors">
                      <MoreVertical className="w-5 h-5 text-gray-400" />
                    </button>

                    {openMenuId === project.idProjet && (
                      <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg py-1 min-w-[180px] z-10">
                        <button onClick={() => handleChangeStatus(project.idProjet, 'En_cours')} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-2"><Edit className="w-4 h-4" /> En cours</button>
                        <button onClick={() => handleChangeStatus(project.idProjet, 'Termine')} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-2"><Edit className="w-4 h-4" /> Terminé</button>
                        <button onClick={() => handleArchiveProject(project.idProjet)} className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-2"><Archive className="w-4 h-4" /> Archiver</button>
                        <div className="border-t border-gray-200 my-1"></div>
                        <button onClick={() => handleDeleteProject(project.idProjet)} className="w-full text-left px-4 py-2 text-sm hover:bg-red-50 text-red-600 flex items-center gap-2"><Trash2 className="w-4 h-4" /> Supprimer</button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-gray-600 mb-2">Créé le {formatDate(project.dateCreation)}</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${status.color}`}>{status.label}</span>
                </div>

                <div className="flex gap-2">
                  <button onClick={() => onOpenProject(project.idProjet)} className="flex-1 bg-[#1e3a8a] text-white px-4 py-2 rounded-lg hover:bg-[#1e40af] flex items-center justify-center gap-2">
                    <ExternalLink className="w-4 h-4" /> Ouvrir
                  </button>
                  <button className="flex-1 border border-gray-300 bg-white text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors" onClick={() => alert('Dossier en dev')}>Dossier</button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-12 text-center mb-8">
          <p className="text-gray-500 text-lg">Aucun projet trouvé</p>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-5 text-center">
          <p className="text-sm text-gray-600 mb-1">Nombre total</p>
          <p className="text-4xl font-bold text-[#1e3a8a]">{stats.total}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-5 text-center">
          <p className="text-sm text-gray-600 mb-1">Actifs</p>
          <p className="text-4xl font-bold text-[#1e3a8a]">{stats.actifs}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-5 text-center">
          <p className="text-sm text-gray-600 mb-1">Archivés</p>
          <p className="text-4xl font-bold text-[#1e3a8a]">{stats.archives}</p>
        </div>
      </div>
    </div>
  );
}
