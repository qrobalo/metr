import React, { useState } from 'react';
import { Search, Trash2, ExternalLink } from 'lucide-react';

interface NotificationsProps {
  onOpenProject: (id: number) => void;
  onNotificationRead?: () => void;
}

export default function Notifications({ onOpenProject, onNotificationRead }: NotificationsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNotification, setSelectedNotification] = useState<number | null>(3);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      date: '04/11/2025',
      title: 'Vous avez été ajouté à un projet',
      message: null,
      isRead: true
    },
    {
      id: 2,
      date: '02/11/2025',
      title: 'Vous avez été ajouté à une bibliothèque',
      message: null,
      isRead: true
    },
    {
      id: 3,
      date: '31/10/2015',
      title: "Vous avez été supprimé d'un projet",
      message:
        'Paul Dupont vous a supprimé du projet "Immeuble Haussmannien". Vous n\'avez plus accès à ce projet.',
      isRead: false,
      projectId: 1,
      projectRemoved: true
    }
  ]);

  const handleDeleteNotification = (notifId: number, e: React.MouseEvent) => {
    e.stopPropagation();

    if (confirm('Êtes-vous sûr de vouloir supprimer cette notification ?')) {
      setNotifications(prev => prev.filter(n => n.id !== notifId));

      if (selectedNotification === notifId) {
        setSelectedNotification(null);
      }

      if (onNotificationRead) onNotificationRead();
    }
  };

  const handleOpenProject = (projectId: number) => {
    onOpenProject(projectId);
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const selected = notifications.find(n => n.id === selectedNotification);

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <h2 className="text-3xl font-bold text-[#1e3a8a] mb-8">Notifications</h2>

      {/* GRID STRUCTURE REWORKED */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

        {/* LEFT COLUMN */}
        <div className="bg-white rounded-xl shadow-md p-6 h-full flex flex-col">

          {/* Search */}
          <div className="relative mb-4">
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher dans les notifications"
              className="w-full pl-10 px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>

          {/* Stats */}
          <p className="text-sm text-gray-600 mb-4">
            <span className="font-semibold">{notifications.length} Notifications</span> / {unreadCount} non lues
          </p>

          {/* SCROLLABLE LIST FIX */}
          <div className="border border-gray-200 rounded-lg overflow-hidden flex-1">
            <div className="max-h-[520px] overflow-y-auto">
              <table className="w-full">
                <thead className="bg-gray-50 sticky top-0 z-10">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Date</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Titre</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {notifications.map(notification => (
                    <tr
                      key={notification.id}
                      onClick={() => setSelectedNotification(notification.id)}
                      className={`cursor-pointer transition-colors ${
                        selectedNotification === notification.id
                          ? 'bg-blue-50'
                          : notification.isRead
                          ? 'bg-white hover:bg-gray-50'
                          : 'bg-gray-50 hover:bg-gray-100'
                      }`}
                    >
                      <td className="px-4 py-3 text-sm text-gray-600">{notification.date}</td>
                      <td className="px-4 py-3 text-sm text-gray-900">{notification.title}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={(e) => handleDeleteNotification(notification.id, e)}
                          className="text-gray-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-md p-8 min-h-[400px] flex flex-col">
          {selected ? (
            <>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">{selected.title}</h3>
                  <p className="text-sm text-gray-500 mt-1">{selected.date}</p>
                </div>

                <button
                  onClick={(e) => handleDeleteNotification(selected.id, e as any)}
                  className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>

              {selected.message && (
                <p className="text-gray-700 leading-relaxed mb-6">{selected.message}</p>
              )}

              {/* Show project button ONLY if not removed */}
              {selected.projectId && !selected.projectRemoved && (
                <button
                  onClick={() => handleOpenProject(selected.projectId!)}
                  className="px-6 py-3 rounded-lg font-medium bg-[#1e3a8a] text-white hover:bg-[#1e40af] flex items-center gap-2 w-fit transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  Ouvrir le projet
                </button>
              )}
            </>
          ) : (
            <div className="text-center text-gray-500 py-12">
              Sélectionnez une notification pour voir les détails
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
