import React, { useState } from 'react';
import { Search, HelpCircle, BookOpen, FileText, MessageCircle, Mail, ChevronRight, ChevronDown } from 'lucide-react';

export default function Help() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  const categories = [
    {
      id: 'start',
      title: 'Premiers pas',
      icon: HelpCircle,
      color: 'bg-blue-500',
      articles: [
        'Comment créer mon premier projet ?',
        'Comment ajouter des plans à un projet ?',
        'Comment inviter des collaborateurs ?',
        'Comment gérer mes bibliothèques ?'
      ]
    },
    {
      id: 'projects',
      title: 'Gestion des projets',
      icon: FileText,
      color: 'bg-green-500',
      articles: [
        'Comment modifier un projet existant ?',
        'Comment archiver un projet ?',
        'Comment exporter les données d\'un projet ?',
        'Comment gérer les versions de plans ?'
      ]
    },
    {
      id: 'library',
      title: 'Bibliothèques',
      icon: BookOpen,
      color: 'bg-purple-500',
      articles: [
        'Comment créer une bibliothèque ?',
        'Comment importer des articles depuis Excel ?',
        'Comment partager ma bibliothèque ?',
        'Comment organiser mes articles ?'
      ]
    },
    {
      id: 'account',
      title: 'Mon compte',
      icon: MessageCircle,
      color: 'bg-orange-500',
      articles: [
        'Comment modifier mes informations personnelles ?',
        'Comment changer mon mot de passe ?',
        'Comment gérer mes notifications ?',
        'Comment supprimer mon compte ?'
      ]
    }
  ];

  const faq = [
    {
      question: 'Comment puis-je mesurer sur un plan ?',
      answer: 'Utilisez l\'outil de mesure dans la visionneuse de plans. Cliquez sur deux points pour mesurer la distance.'
    },
    {
      question: 'Puis-je collaborer avec mon équipe ?',
      answer: 'Oui ! Vous pouvez inviter des collaborateurs sur vos projets avec différents niveaux d\'accès (Lecteur ou Éditeur).'
    },
    {
      question: 'Quels formats de fichiers sont supportés ?',
      answer: 'Pour les plans : DWG, PDF. Pour les documents : PDF, JPG, PNG, DOC, DOCX, XLS, XLSX.'
    },
    {
      question: 'Comment exporter mes données ?',
      answer: 'Vous pouvez exporter vos projets au format PDF ou Excel depuis la page du projet.'
    }
  ];

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    const category = categories.find(c => c.id === categoryId);
    alert(`Articles de la catégorie "${category?.title}" :\n\n${category?.articles.join('\n')}`);
  };

  const handleChatClick = () => {
    alert('Fonctionnalité de chat en direct bientôt disponible !\nVous serez redirigé vers notre plateforme de support.');
  };

  const handleEmailClick = () => {
    window.location.href = 'mailto:support@metr.fr?subject=Demande de support';
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-[#1e3a8a] mb-4">
          Comment pouvons-nous vous aider ?
        </h1>
        <p className="text-gray-600 text-lg mb-8">
          Recherchez dans notre base de connaissances ou contactez notre support
        </p>

        {/* Search Bar */}
        <div className="max-w-2xl mx-auto relative">
          <Search className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher un article d'aide..."
            className="w-full pl-12 pr-4 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent text-lg"
          />
        </div>
      </div>

      {/* Categories Grid - MAINTENANT CLIQUABLES */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <button
              key={category.id}
              onClick={() => handleCategoryClick(category.id)}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-all cursor-pointer group text-left w-full"
            >
              <div className={`${category.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-lg text-gray-900 mb-2">
                {category.title}
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                {category.articles.length} articles
              </p>
              <div className="text-[#1e3a8a] font-medium text-sm flex items-center gap-1 group-hover:gap-2 transition-all">
                Voir les articles
                <ChevronRight className="w-4 h-4" />
              </div>
            </button>
          );
        })}
      </div>

      {/* FAQ Section - MAINTENANT VRAIMENT CLIQUABLE */}
      <div className="bg-white rounded-lg shadow-md p-8 mb-8">
        <h2 className="text-2xl font-bold text-[#1e3a8a] mb-6">
          Questions fréquentes
        </h2>
        <div className="space-y-4">
          {faq.map((item, idx) => (
            <div key={idx} className="border-b border-gray-200 pb-4">
              <button
                onClick={() => toggleFaq(idx)}
                className="w-full flex items-center justify-between cursor-pointer text-left hover:text-[#1e3a8a] transition-colors"
              >
                <span className="font-medium text-gray-900">
                  {item.question}
                </span>
                <ChevronDown 
                  className={`w-5 h-5 text-gray-400 transition-transform ${
                    openFaqIndex === idx ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openFaqIndex === idx && (
                <div className="mt-3 text-gray-600 pl-4 animate-fadeIn">
                  {item.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Contact Support - BOUTONS FONCTIONNELS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <button
          onClick={handleChatClick}
          className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-md p-8 text-white hover:shadow-xl transition-all text-left"
        >
          <MessageCircle className="w-12 h-12 mb-4" />
          <h3 className="text-2xl font-bold mb-2">Chat en direct</h3>
          <p className="mb-6 opacity-90">
            Discutez avec notre équipe support en temps réel
          </p>
          <div className="bg-white text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition-colors font-medium inline-block">
            Démarrer une conversation
          </div>
        </button>

        <button
          onClick={handleEmailClick}
          className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-md p-8 text-white hover:shadow-xl transition-all text-left"
        >
          <Mail className="w-12 h-12 mb-4" />
          <h3 className="text-2xl font-bold mb-2">Email support</h3>
          <p className="mb-6 opacity-90">
            Envoyez-nous un email, nous répondons sous 24h
          </p>
          <div className="bg-white text-purple-600 px-6 py-3 rounded-lg hover:bg-purple-50 transition-colors font-medium inline-block">
            support@metr.fr
          </div>
        </button>
      </div>
    </div>
  );
}