import React from 'react';
import { Plus, ExternalLink, MoreVertical, TrendingUp, TrendingDown } from 'lucide-react';

interface DashboardProps {
  projects: any[];
  onCreateProject: () => void;
  onOpenProject: (id: number) => void;
}

export default function Dashboard({ projects, onCreateProject, onOpenProject }: DashboardProps) {
  const recentProjects = projects.slice(0, 6);

  const getStatusDisplay = (statut: string) => {
    const statusMap: any = {
      'En_cours': { label: 'En cours', color: 'bg-green-100 text-green-700' },
      'Termine': { label: 'Terminé', color: 'bg-blue-100 text-blue-700' },
      'En_attente': { label: 'Brouillon', color: 'bg-yellow-100 text-yellow-700' },
      'Archive': { label: 'Archivé', color: 'bg-gray-100 text-gray-700' }
    };
    return statusMap[statut] || statusMap['En_attente'];
  };

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const stats = {
    projetsActifs: projects.filter(p => p.statut === 'En_cours').length,
    projetsTotal: projects.length,
    projetsTermines: projects.filter(p => p.statut === 'Termine').length,

    projetsThisMonth: projects.filter(p => {
      const creationDate = new Date(p.dateCreation);
      return creationDate.getMonth() === currentMonth && creationDate.getFullYear() === currentYear;
    }).length,

    projetsLastMonth: projects.filter(p => {
      const creationDate = new Date(p.dateCreation);
      const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
      const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;
      return creationDate.getMonth() === lastMonth && creationDate.getFullYear() === lastMonthYear;
    }).length,

    projetsTerminesThisMonth: projects.filter(p => {
      if (p.statut !== 'Termine') return false;
      const creationDate = new Date(p.dateCreation);
      return creationDate.getMonth() === currentMonth && creationDate.getFullYear() === currentYear;
    }).length
  };

  const projectTrend = stats.projetsThisMonth - stats.projetsLastMonth;
  const hasTrendUp = projectTrend > 0;

  const estimatedM2 = stats.projetsActifs * 187;
  const m2LastMonth = stats.projetsLastMonth * 187;
  const m2Trend = estimatedM2 - m2LastMonth;

  const recentExports = stats.projetsTerminesThisMonth;

  const formatDate = (dateString: string) => {
    if (!dateString) return 'Date inconnue';
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-12">

      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-[#1e3a8a]">Mes projets récents</h2>
        <button 
          onClick={onCreateProject} 
          className="bg-[#f97316] text-white px-5 py-2.5 rounded-lg hover:bg-[#ea580c] transition-colors font-medium flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Nouveau projet
        </button>
      </div>

      {/* Projects Grid */}
      {recentProjects.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {recentProjects.map((project) => {
            const status = getStatusDisplay(project.statut);
            return (
              <div 
                key={project.idProjet} 
                className="bg-white rounded-xl shadow-sm p-5 border border-gray-100 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-gray-900 mb-1 line-clamp-1">{project.nom}</h3>
                    <p className="text-sm text-gray-500 line-clamp-1">{project.client || 'Rénovation Paris'}</p>
                  </div>
                  <button className="p-1 hover:bg-gray-100 rounded transition-colors">
                    <MoreVertical className="w-5 h-5 text-gray-400" />
                  </button>
                </div>

                <p className="text-sm text-gray-600 mb-2">Créé le {formatDate(project.dateCreation)}</p>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${status.color}`}>{status.label}</span>

                <div className="flex gap-2 mt-4">
                  <button 
                    onClick={() => onOpenProject(project.idProjet)}
                    className="flex-1 bg-[#1e3a8a] text-white px-4 py-2 rounded-lg hover:bg-[#1e40af] transition-colors font-medium flex items-center justify-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" /> Ouvrir
                  </button>
                  <button 
                    onClick={() => alert('Fonctionnalité Dossier en développement')}
                    className="flex-1 border border-gray-300 bg-white text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                  >
                    Dossier
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center border border-gray-100">
          <p className="text-gray-500 mb-4 text-lg">Aucun projet pour le moment</p>
          <button 
            onClick={onCreateProject} 
            className="bg-[#f97316] text-white px-6 py-3 rounded-lg hover:bg-[#ea580c] transition-colors font-medium inline-flex items-center gap-2"
          >
            <Plus className="w-5 h-5" /> Créer votre premier projet
          </button>
        </div>
      )}

      {/* Statistics */}
      <div>
        <h2 className="text-2xl font-bold text-[#1e3a8a] mb-6">Mes statistiques</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

          {/* Stat card */}
          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">Projets actifs</p>
            <p className="text-3xl font-bold text-[#1e3a8a]">{stats.projetsActifs}</p>
            <div className="flex items-center gap-1 mt-3 text-sm">
              {hasTrendUp ? (
                <><TrendingUp className="w-4 h-4 text-green-500" /><p className="text-green-600">+{projectTrend} ce mois</p></>
              ) : projectTrend < 0 ? (
                <><TrendingDown className="w-4 h-4 text-red-500" /><p className="text-red-600">{projectTrend} ce mois</p></>
              ) : (
                <p className="text-gray-600">Stable</p>
              )}
            </div>
          </div>

          {/* m² */}
          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">m² estimés</p>
            <p className="text-3xl font-bold text-[#1e3a8a]">{estimatedM2.toLocaleString()}</p>
            <div className="flex items-center gap-1 mt-3 text-sm">
              {m2Trend > 0 ? (
                <><TrendingUp className="w-4 h-4 text-green-500" /><p className="text-green-600">+{m2Trend.toLocaleString()} vs mois passé</p></>
              ) : m2Trend < 0 ? (
                <><TrendingDown className="w-4 h-4 text-red-500" /><p className="text-red-600">{m2Trend.toLocaleString()} vs mois passé</p></>
              ) : (
                <p className="text-gray-600">Stable</p>
              )}
            </div>
          </div>

          {/* Exports */}
          <div className="bg-white rounded-xl shadow-sm p-5 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">Exports réalisés</p>
            <p className="text-3xl font-bold text-[#1e3a8a]">{recentExports}</p>
            <p className="text-sm text-gray-600 mt-3">{stats.projetsTermines} terminés au total</p>
          </div>
        </div>
      </div>
    </div>
  );
}
